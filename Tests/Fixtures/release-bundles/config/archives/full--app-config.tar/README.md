TEST: not a config document
